zip -rj /Volumes/GJJexFAT/development/upload//southAmerica_argentina.ghz /Volumes/GJJexFAT/development/osm/argentina-latest.osm-gh/*
zip -rj /Volumes/GJJexFAT/development/upload//southAmerica_bolivia.ghz /Volumes/GJJexFAT/development/osm/bolivia-latest.osm-gh/*
zip -rj /Volumes/GJJexFAT/development/upload//southAmerica_brazil.ghz /Volumes/GJJexFAT/development/osm/brazil-latest.osm-gh/*
zip -rj /Volumes/GJJexFAT/development/upload//southAmerica_chile.ghz /Volumes/GJJexFAT/development/osm/chile-latest.osm-gh/*
zip -rj /Volumes/GJJexFAT/development/upload//southAmerica_colombia.ghz /Volumes/GJJexFAT/development/osm/colombia-latest.osm-gh/*
zip -rj /Volumes/GJJexFAT/development/upload//southAmerica_ecuador.ghz /Volumes/GJJexFAT/development/osm/ecuador-latest.osm-gh/*
zip -rj /Volumes/GJJexFAT/development/upload//southAmerica_peru.ghz /Volumes/GJJexFAT/development/osm/peru-latest.osm-gh/*
zip -rj /Volumes/GJJexFAT/development/upload//southAmerica_uruguay.ghz /Volumes/GJJexFAT/development/osm/uruguay-latest.osm-gh/*
