package com.junjunguo.pocketmaps.model.listeners;

/**
 * This file is part of PocketMaps
 * <p/>
 * Author: Paul Kashofer (Austria) Starcommander@github.com
 */
public interface OnProgressListener {
    void onProgress(int progress);
}
