#!/bin/sh

platformio init --ide clion --board megaatmega2560