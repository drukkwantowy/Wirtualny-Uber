#!/bin/sh

platformio init --ide clion --board uno